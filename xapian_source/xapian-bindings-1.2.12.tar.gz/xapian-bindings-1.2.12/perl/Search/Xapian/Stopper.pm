package Search::Xapian::Stopper;

1;
