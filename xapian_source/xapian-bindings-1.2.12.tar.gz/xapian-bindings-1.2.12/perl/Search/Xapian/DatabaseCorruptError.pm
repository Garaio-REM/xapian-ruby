package Search::Xapian::DatabaseCorruptError;

=head1 NAME

Search::Xapian::DatabaseCorruptError -  DatabaseCorruptError indicates database corruption was detected. 


=head1 DESCRIPTION


=cut
1;
