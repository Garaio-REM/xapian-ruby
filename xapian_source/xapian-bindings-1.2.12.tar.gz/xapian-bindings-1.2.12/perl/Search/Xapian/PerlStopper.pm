package Search::Xapian::PerlStopper;

1;
