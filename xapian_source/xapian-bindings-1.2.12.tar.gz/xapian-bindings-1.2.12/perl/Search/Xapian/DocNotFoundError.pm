package Search::Xapian::DocNotFoundError;

=head1 NAME

Search::Xapian::DocNotFoundError -  Indicates an attempt to access a document not present in the database. 


=head1 DESCRIPTION


=cut
1;
